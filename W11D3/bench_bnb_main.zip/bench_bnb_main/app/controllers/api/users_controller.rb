class Api::UsersController < ApplicationController
end
