/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./frontend/twitter.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./frontend/api_util.js":
/*!******************************!*\
  !*** ./frontend/api_util.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

const APIUtil = {
  followUser: id => {
    console.log(id);
    $.ajax({
      url: `/users/${id}/follow`, //somehow params[:user_id] in follows_controller.rb is undefined
      method: 'POST',
      dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
    }).then(()=>{
      this.followState = "followed";
      this.render();
    });
  },

  unfollowUser: id => {
    $.ajax({
      url: `/users/${id}/follow`, 
      method: "DELETE",
      dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
    }).then(()=>{
      this.followState = "unfollowed";
      this.render();
    });
  }
};

module.exports = APIUtil;

/***/ }),

/***/ "./frontend/follow_toggle.js":
/*!***********************************!*\
  !*** ./frontend/follow_toggle.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const APIUtil = __webpack_require__(/*! ./api_util.js */ "./frontend/api_util.js");

class FollowToggle{

    constructor($element){
        this.userId = $element.data('user-id');
        this.followState = $element.data('initial-follow-state');
        this.$element = $element;
        this.render();
        this.$element.on("click",(e)=>{
          this.handleClick(e);
        });
    }
    
    render(){
        if(this.followState === "unfollowed"){
          this.$element.text("Follow!");
        }
        else if(this.followState === "followed"){
          this.$element.text("Unfollow!");
        }
    }
    // user_follow DELETE /users/:user_id/follow(.:format) follows#destroy
    // POST   /users/:user_id/follow(.:format) follows#create
    handleClick(e){
      e.preventDefault();
      // if the user is following -> we want this to be a delete request
      // if it's not following -> want post request
      // let httpVerb;
      // let newFollowState;
      // console.log(this.followState);
      // if(this.followState === "unfollowed"){
      //   httpVerb = "POST";
      //   newFollowState = "followed";
      // }
      // else if(this.followState = "followed"){
      //   httpVerb = "DELETE";
      //   newFollowState = "unfollowed";
      // }
      // $.ajax({
      //     url: `/users/${this.userId}/follow`, 
      //     method: httpVerb,
      //     dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
      // }).then(()=>{
      //   //toggle followstate and render
      //   this.followState = newFollowState;
      //   this.render();
      // });
      if(this.followState === "followed"){
          APIUtil.unfollowUser.bind(this)(this.userId);
          //APIUtil.unfollowUser.call(this, this.userId);
      }
      else if(this.followState === "unfollowed"){
          APIUtil.followUser.call(this, this.userId);
      }
    }
}




module.exports = FollowToggle;




/***/ }),

/***/ "./frontend/twitter.js":
/*!*****************************!*\
  !*** ./frontend/twitter.js ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

const FollowToggle = __webpack_require__(/*! ./follow_toggle.js */ "./frontend/follow_toggle.js");

// jquery -> pass in a function -> function goes to callback queue -> doesn't get called until DOM is loaded
// function callback(){};
// $(callback);
$(() => {
  const followButtons = $("button.follow-toggle"); // array of buttons 
  //console.log(followButtons);
  $("button.follow-toggle").each((undefined, button) => new FollowToggle($(button)));
});





/***/ })

/******/ });
//# sourceMappingURL=bundle.js.map