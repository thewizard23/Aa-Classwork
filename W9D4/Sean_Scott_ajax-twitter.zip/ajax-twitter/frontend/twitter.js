const FollowToggle = require("./follow_toggle.js");

// jquery -> pass in a function -> function goes to callback queue -> doesn't get called until DOM is loaded
// function callback(){};
// $(callback);
$(() => {
  const followButtons = $("button.follow-toggle"); // array of buttons 
  //console.log(followButtons);
  $("button.follow-toggle").each((undefined, button) => new FollowToggle($(button)));
});



