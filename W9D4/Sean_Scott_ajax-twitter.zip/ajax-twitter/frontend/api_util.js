const APIUtil = {
  followUser: id => {
    console.log(id);
    $.ajax({
      url: `/users/${id}/follow`, //somehow params[:user_id] in follows_controller.rb is undefined
      method: 'POST',
      dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
    }).then(()=>{
      this.followState = "followed";
      this.render();
    });
  },

  unfollowUser: id => {
    $.ajax({
      url: `/users/${id}/follow`, 
      method: "DELETE",
      dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
    }).then(()=>{
      this.followState = "unfollowed";
      this.render();
    });
  }
};

module.exports = APIUtil;