const APIUtil = require('./api_util.js');

class FollowToggle{

    constructor($element){
        this.userId = $element.data('user-id');
        this.followState = $element.data('initial-follow-state');
        this.$element = $element;
        this.render();
        this.$element.on("click",(e)=>{
          this.handleClick(e);
        });
    }
    
    render(){
        if(this.followState === "unfollowed"){
          this.$element.text("Follow!");
        }
        else if(this.followState === "followed"){
          this.$element.text("Unfollow!");
        }
    }
    // user_follow DELETE /users/:user_id/follow(.:format) follows#destroy
    // POST   /users/:user_id/follow(.:format) follows#create
    handleClick(e){
      e.preventDefault();
      // if the user is following -> we want this to be a delete request
      // if it's not following -> want post request
      // let httpVerb;
      // let newFollowState;
      // console.log(this.followState);
      // if(this.followState === "unfollowed"){
      //   httpVerb = "POST";
      //   newFollowState = "followed";
      // }
      // else if(this.followState = "followed"){
      //   httpVerb = "DELETE";
      //   newFollowState = "unfollowed";
      // }
      // $.ajax({
      //     url: `/users/${this.userId}/follow`, 
      //     method: httpVerb,
      //     dataType: 'json' //unspecified -> will choose first in hierarchy in controller 
      // }).then(()=>{
      //   //toggle followstate and render
      //   this.followState = newFollowState;
      //   this.render();
      // });
      if(this.followState === "followed"){
          APIUtil.unfollowUser.bind(this)(this.userId);
          //APIUtil.unfollowUser.call(this, this.userId);
      }
      else if(this.followState === "unfollowed"){
          APIUtil.followUser.call(this, this.userId);
      }
    }
}




module.exports = FollowToggle;


