
const dogs = {
  "Corgi": "https://www.akc.org/dog-breeds/cardigan-welsh-corgi/",
  "Australian Shepherd": "https://www.akc.org/dog-breeds/australian-shepherd/",
  "Affenpinscher": "https://www.akc.org/dog-breeds/affenpinscher/",
  "American Staffordshire Terrier": "https://www.akc.org/dog-breeds/american-staffordshire-terrier/",
  "Tosa": "https://www.akc.org/dog-breeds/tosa/",
  "Labrador Retriever": "https://www.akc.org/dog-breeds/labrador-retriever/",
  "French Bulldog": "https://www.akc.org/dog-breeds/french-bulldog/" 
};

function dogLinkCreator(){
  // debugger
  let newArr = Object.keys(dogs);
  let dogLink = []
  for (let index = 0; index < newArr.length; index++) {
    var newEle = document.createElement('a');
    newEle.innerHTML = newArr[index];
    newEle.href = dogs[newArr[index]];
    var newLi = document.createElement('li');
    newLi.className = 'dog-link';
    newEle.appendChild(newLi);
    dogLink.push(newLi);
  }
  return dogLink;
}

function attachDogLinks(){
  debugger
  let dogLinks = dogLinkCreator();
  for (let index = 0; index < dogLinks.length; index++) {
    let ulEle = document.querySelectorAll(".drop-down-dog-list");
    (ulEle).appendChild(dogLinks[index]);
  }
}

attachDogLinks();
