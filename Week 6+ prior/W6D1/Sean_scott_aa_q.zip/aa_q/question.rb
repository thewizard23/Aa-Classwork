require_relative 'questions_database'
require_relative 'user'
require_relative 'reply'
require_relative 'question_follow'

class Question 
  def self.find_by_id(id)
    question_query = QuestionsDatabase.instance.execute(<<-SQL, id)
    SELECT
        *
    FROM
        questions
    WHERE
        id = ?
    SQL
  
    question_query.nil? ? nil : Question.new(question_query.first)
  end

  
  def self.find_by_author_id(author_id)
    question_query = QuestionsDatabase.instance.execute(<<-SQL, author_id)
    SELECT
        *
    FROM
        questions
    WHERE
        author_id = ?
    SQL
  
    question_query.map { |q| Question.new(q)}
  end
  
  def self.most_followed(n)
   QuestionFollow.most_followed_questions(n).first
  end
  
  attr_reader :id

  def initialize(options)
    @id = options['id'] 
    @title = options['title']
    @body = options['body']
    @author_id = options['author_id']
  end 

  def author 
    User.find_by_id(id)
  end

  def replies
    Reply.find_by_question_id(id)
  end

  def followers
    QuestionFollow.followers_for_question_id(id)
  end

end