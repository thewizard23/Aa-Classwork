require_relative 'questions_database'

class QuestionLike
    
  def self.find_by_id(id)
    question_like_query = QuestionsDatabase.instance.execute(<<-SQL, id)
    SELECT
        *
    FROM
        question_likes
    WHERE
        id = ?
    SQL
    
    question_like_query.nil? ? nil : QuestionLike.new(question_like_query.first)
  end

  def self.likers_for_question_id(question_id)
    likers = QuestionsDatabase.instance.execute(<<-SQL, question_id)
    SELECT
      *
    FROM
      question_likes
    JOIN
      users on question_likes.user_id = users.id
    WHERE
      question_id = ?
    SQL

    likers.map { |liker| User.new(liker)}
  end

  
  def self.num_likes_for_question_id(question_id)
    num_likes = QuestionsDatabase.instance.execute(<<-SQL, question_id)
    SELECT
      COUNT(*) AS num_likes
    FROM
      question_likes
    JOIN
      users ON question_likes.user_id = users.id
    WHERE
      question_id = ?
    ORDER BY
      num_likes
    SQL
    
    num_likes
  end
  
  attr_reader :id, :user_id, :question_id

  def initialize(options)
    @id = options['id'] 
    @user_id = options['user_id']
    @question_id = options['question_id']
  end

end