require_relative 'questions_database'
require_relative 'user'

class QuestionFollow
  def self.find_by_id(id)
    question_follow_query = QuestionsDatabase.instance.execute(<<-SQL, id)
    SELECT
        *
    FROM
        question_follows
    WHERE
        id = ?
    SQL
    
    question_follow_query.nil? ? nil : QuestionFollow.new(question_follow_query.first)
  end

  def self.followers_for_question_id(question_id)
    follower_query = QuestionsDatabase.instance.execute(<<-SQL, question_id)
    SELECT
      *
    FROM
      question_follows
    JOIN
      users on question_follows.user_id = users.id
    WHERE
      question_id = ?
    SQL

    follower_query.map { |user| User.new(user) }
  end

  def self.followed_questions_for_user_id(user_id)
    questions_query = QuestionsDatabase.instance.execute(<<-SQL, user_id)
    SELECT
      *
    FROM
      question_follows
    JOIN
      questions on question_follows.question_id = questions.id
    WHERE
      user_id = ?
    SQL

    questions_query.map { |question| Question.new(question) }
    
  end

  def self.most_followed_questions(n)
    most_followed_ques = QuestionsDatabase.instance.execute(<<-SQL, n)
      SELECT
        *
      FROM
        question_follows
      JOIN
        questions on question_follows.question_id = questions.id
      GROUP BY
        questions.id
      ORDER BY
       'COUNT(*), DESC'
      LIMIT
        ?
    SQL
    
    most_followed_ques.map {|ques| Question.new(ques)}
  end

   
  attr_reader :id, :user_id, :question_id

  def initialize(options)
    @id = options['id'] 
    @user_id = options['user_id']
    @question_id = options['question_id']
  end 


end