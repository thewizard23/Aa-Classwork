class AttrAccessorObject
  def self.my_attr_accessor(*names) # [:fname, :lname, :age] e.g.
    names.each do |name|
      define_method("#{name}") do
        instance_variable_get("@#{name}")
      end

      define_method("#{name}=") do |val|
        instance_variable_set("@#{name}", val)
      end
    end
  end

end


 