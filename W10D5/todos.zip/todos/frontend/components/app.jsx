import React from 'react';

const App = () => {
    return (
        <div>
            <h1>App component</h1>
        </div>
    )
}
export default App;