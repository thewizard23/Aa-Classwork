class UsersController < ApplicationController
    def index
       users = User.all
       render :index
    end

    def create 
        user = User.create
        if user.save! 

        else
            redirect_to users_url
        end
    end

    def new
        user = User.new
        render :new
    end

    def destroy

    end

    def update 
        
    end
end
