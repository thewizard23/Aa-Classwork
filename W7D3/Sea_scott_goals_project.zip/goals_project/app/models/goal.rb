class Goal < ApplicationRecord


end
