require 'rails_helper'

RSpec.describe UsersController, type: :controller do
    describe "GET#new" do
        it "renders the new user template" do
            get :new
            expect(respond_to render_template(:new))
        end
    end

    describe "POST#create" do
        it "renders the create user template" do
                let(user_params) { user: {username: "Shawn", password: "password"} }
                expect(respond_to render_template(:new))
        end
    end
end
