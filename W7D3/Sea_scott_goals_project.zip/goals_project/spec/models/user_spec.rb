require 'rails_helper'



RSpec.describe User, type: :model do

  subject(:user) {User.create!(username: "sean", password: "disney")}
  it {should validate_length_of(:password).is_at_least(6)}
  it {should validate_presence_of(:password_digest)}
   it {should validate_uniqueness_of(:username)}
   it {should validate_presence_of(:username)}

  
  describe 'find user password and name' do
    it 'does not save password' do
      User.create!(username: 'sean', password: 'password')
      user = User.find_by(username: 'sean')
      expect(user.password).not_to be('password')
  end

  it 'encrypts password using Bcrypt' do 
    expect(BCrypt::Password).to receive(:create)
    User.new(username:'sean', password:'password')
  end
end



end
