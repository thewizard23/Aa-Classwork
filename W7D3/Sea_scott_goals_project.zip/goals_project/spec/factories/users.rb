FactoryBot.define do
  factory :user do
    
  end
end
