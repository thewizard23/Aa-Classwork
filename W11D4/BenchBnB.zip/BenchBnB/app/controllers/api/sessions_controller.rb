class Api::SessionsController < ApplicationController
  def create
    @user = User.find_by_credentials(params[:user][:username], params[:user][:password])
    if @user.nil?
      render json: ['Nope. Wrong credentials!'], status: 404
    else
      login!(@user)
      render json: { message: "HELP! I'm in the sessions controller!"}
    end
  end

  def destroy
    if current_user
      logout!
      render json: {}
    else
      render json: ['Nope. No Current User'], status: 404
    end
  end
end
