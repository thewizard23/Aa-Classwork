const View = require("./ttt-view.js"); // require appropriate file
const Game = require("./game.js"); // require appropriate file


$(() => {
  // Your code here
    const ticTacToeBoard = $('.ttt');
    const newGame = new Game();
    const newView = new View(newGame, ticTacToeBoard);
  });
