class View {
  constructor(game, $el) {
    this.game = game;
    this.board = $el;
    this.size = 9;
    this.setupBoard();
    this.bindEvents();
  }

  bindEvents() {
    $('li').on('click', function(){
      let cell_id = $(this).attr('id');
      let row = Math.floor(cell_id / 3);
      let col = (cell_id % 3);
      this.game.playMove([row,col]);
      this.makeMove($(this));
    });
  }

  makeMove($square) {
    $square.addClass('clicked');
    if (this.game.winner !== null){
        alert('congrats, you won!');
    }
  };

  setupBoard() {
    const $ul = $('<ul></ul>');
    this.board.append($ul);
    for(let i = 0; i < this.size; i++){
      let $li = $('<li></li>');
      $ul.append($li);
      $li.attr('id', i);
    }


    
    // $('li').on('mouseover', 'background-color:yellow;')
    // make grid to represent the board 
    // use <ul>; use <li> as cell

  }
}


module.exports = View;
